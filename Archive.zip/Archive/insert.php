<?php
$name = $_POST['name']
$adress = $_POST['adress']
$city = $_POST['city']
$phone = $_POST['phone']
$email = $_POST['email']
$password = $_POST['password']

if (empty($phone) && empty($email))
{
	echo "You cannot register without an email or phone";
	die();
}

?>